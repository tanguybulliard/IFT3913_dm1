/**
 * Core support for the plug-in renderers used by the {@link org.jfree.chart.plot.CategoryPlot} and {@link org.jfree.chart.plot.XYPlot} classes.
 */
package org.jfree.chart.renderer;
