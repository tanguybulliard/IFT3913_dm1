/*
 * Classes used to create chart legends.
 */
package org.jfree.chart.legend;
