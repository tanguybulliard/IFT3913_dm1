/**
 * Classes that can be used for formatting purposes.
 */
package org.jfree.chart.text.format;
