/**
 * A framework for adding annotations to charts.
 */
package org.jfree.chart.annotations;
